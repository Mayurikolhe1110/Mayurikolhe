import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Cloud, Sparkles, Code2, Bot, Users, Lightbulb, MessageSquare,
  Mail, Phone, Github, Linkedin, GraduationCap, ArrowRight, Award,
} from "lucide-react";
import profileImg from "@/assets/profile.jpg";
import certDigital101 from "@/assets/cert-digital-101.jpg";
import certClaude101Real from "@/assets/cert-claude-101-real.jpg";
import certPython from "@/assets/cert-python-essentials.jpg";
import certDataViz from "@/assets/cert-data-viz.jpg";
import certPython2 from "@/assets/cert-python-2.jpg";
import certAiFrameworkReal from "@/assets/cert-ai-framework-real.jpg";
import certAiStudentsReal from "@/assets/cert-ai-students-real.jpg";
import certAiNonprofits from "@/assets/cert-ai-nonprofits.jpg";

const skills = [
  { name: "Cloud Computing", icon: Cloud, desc: "AWS, Azure & cloud architecture fundamentals" },
  { name: "Prompt Engineering", icon: Sparkles, desc: "Crafting effective prompts for LLMs" },
  { name: "Basic Python", icon: Code2, desc: "Scripting, automation & problem solving" },
  { name: "AI Tools", icon: Bot, desc: "Hands-on with Claude, ChatGPT & more" },
  { name: "Communication", icon: MessageSquare, desc: "Clear written & verbal expression" },
  { name: "Teamwork", icon: Users, desc: "Collaboration in academic projects" },
  { name: "Problem Solving", icon: Lightbulb, desc: "Analytical & structured thinking" },
];

const achievements = [
  { img: certPython, title: "Python Essentials 1", date: "30 Mar 2026", desc: "Cisco Networking Academy & Python Institute · MIT Academy of Engineering, Pune." },
  { img: certPython2, title: "Python Essentials 2", date: "31 Mar 2026", desc: "Advanced Python concepts via Cisco Networking Academy & Python Institute." },
  { img: certDigital101, title: "Digital 101 — NASSCOM (Gold)", date: "14 Apr 2026", desc: "FutureSkills Prime · Ministry of Electronics & IT. Cleared with Gold category (93%)." },
  { img: certDataViz, title: "The Importance of Data Visualization", date: "18 Apr 2026", desc: "IBM SkillsBuild completion certificate — fundamentals of effective data viz." },
  { img: certAiStudentsReal, title: "AI Fluency for Students", date: "2026", desc: "Anthropic · Foundations of AI literacy & responsible usage in academics." },
  { img: certAiFrameworkReal, title: "AI Fluency: Framework & Foundations", date: "2026", desc: "Anthropic · Structured framework for understanding modern AI systems." },
  { img: certAiNonprofits, title: "AI Fluency for Nonprofits", date: "2026", desc: "Anthropic × GivingTuesday · AI literacy for the social impact sector." },
  { img: certClaude101Real, title: "Claude 101", date: "2026", desc: "Anthropic · Introduction to Claude — capabilities, prompting & best practices." },
];

const useReveal = () => {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add("in-view")),
      { threshold: 0.12 }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
};

const scrollTo = (id: string) => {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
};

const Nav = () => {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  const links = [
    { id: "profile", label: "Profile" },
    { id: "skills", label: "Skills" },
    { id: "achievements", label: "Achievements" },
    { id: "contact", label: "Contact" },
  ];
  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled ? "py-3" : "py-5"
      }`}
    >
      <nav
        className={`mx-auto max-w-5xl px-5 sm:px-8 flex items-center justify-between rounded-full transition-all duration-500 ${
          scrolled ? "glass-card py-2.5" : "py-3"
        }`}
      >
        <button onClick={() => scrollTo("hero")} className="flex items-center gap-2 font-serif text-lg font-semibold text-primary">
          <span className="grid h-8 w-8 place-items-center rounded-full bg-gradient-to-br from-accent to-rose text-primary text-sm">
            MK
          </span>
          <span className="hidden sm:inline">Mayuri Kohle</span>
        </button>
        <ul className="flex items-center gap-1 sm:gap-2">
          {links.map((l) => (
            <li key={l.id}>
              <button
                onClick={() => scrollTo(l.id)}
                className="px-3 py-1.5 text-xs sm:text-sm font-medium text-muted-foreground hover:text-primary transition-colors rounded-full hover:bg-secondary/60"
              >
                {l.label}
              </button>
            </li>
          ))}
        </ul>
      </nav>
    </header>
  );
};

const Hero = () => (
  <section id="hero" className="relative min-h-screen flex items-center justify-center px-5 pt-28 pb-16">
    <div className="absolute inset-0 -z-10" style={{ background: "var(--gradient-hero)" }} />
    <div className="absolute top-1/4 left-1/4 h-72 w-72 rounded-full bg-rose/40 blur-3xl -z-10 animate-float" />
    <div className="absolute bottom-1/4 right-1/4 h-80 w-80 rounded-full bg-accent/40 blur-3xl -z-10 animate-float" style={{ animationDelay: "2s" }} />

    <div className="text-center max-w-3xl mx-auto animate-fade-in">
      <div className="relative mx-auto mb-8 w-40 h-40 sm:w-48 sm:h-48">
        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-accent via-rose to-sand blur-xl opacity-70" />
        <div className="relative w-full h-full rounded-full p-1.5 bg-gradient-to-br from-white to-accent/60 shadow-[var(--shadow-elegant)]">
          <img
            src={profileImg}
            alt="Mayuri Kohle"
            width={192}
            height={192}
            className="w-full h-full object-cover rounded-full"
          />
        </div>
        <div className="absolute -bottom-1 -right-1 grid h-10 w-10 place-items-center rounded-full bg-white/90 shadow-md backdrop-blur">
          <GraduationCap className="h-5 w-5 text-primary" />
        </div>
      </div>

      <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-card text-xs font-medium text-primary mb-5">
        <Cloud className="h-3.5 w-3.5" /> Cloud Computing Track
      </span>

      <h1 className="font-serif text-5xl sm:text-6xl md:text-7xl font-semibold text-primary leading-[1.05] tracking-tight">
        Mayuri <span className="text-gradient-gold italic">Kohle</span>
      </h1>
      <p className="mt-5 text-base sm:text-lg text-muted-foreground max-w-xl mx-auto leading-relaxed">
        Engineering Student · Cloud Computing Learner · Aspiring Developer
      </p>

      <div className="mt-9 flex flex-wrap justify-center gap-3">
        <Button size="lg" onClick={() => scrollTo("profile")} className="rounded-full px-6 shadow-[var(--shadow-soft)]">
          View Profile <ArrowRight className="ml-1 h-4 w-4" />
        </Button>
        <Button size="lg" variant="secondary" onClick={() => scrollTo("skills")} className="rounded-full px-6">
          View Skills
        </Button>
        <Button size="lg" variant="secondary" onClick={() => scrollTo("achievements")} className="rounded-full px-6">
          View Achievements
        </Button>
        <Button size="lg" variant="outline" onClick={() => scrollTo("contact")} className="rounded-full px-6 bg-white/50 backdrop-blur">
          Contact Me
        </Button>
      </div>
    </div>
  </section>
);

const SectionTitle = ({ eyebrow, title }: { eyebrow: string; title: string }) => (
  <div className="text-center mb-14 reveal">
    <p className="text-xs uppercase tracking-[0.25em] text-gold font-medium mb-3">{eyebrow}</p>
    <h2 className="font-serif text-4xl sm:text-5xl font-semibold text-primary tracking-tight">
      {title}
    </h2>
    <div className="mx-auto mt-4 h-px w-16 bg-gradient-to-r from-transparent via-gold to-transparent" />
  </div>
);

const Profile = () => (
  <section id="profile" className="px-5 py-24">
    <div className="max-w-5xl mx-auto">
      <SectionTitle eyebrow="About" title="My Profile" />
      <div className="glass-card glass-card-hover reveal p-8 sm:p-12 grid md:grid-cols-[260px_1fr] gap-10 items-center">
        <div className="relative mx-auto">
          <div className="absolute -inset-4 rounded-3xl bg-gradient-to-br from-accent/50 to-rose/50 blur-2xl" />
          <img
            src={profileImg}
            alt="Mayuri Kohle profile"
            loading="lazy"
            width={260}
            height={260}
            className="relative w-56 h-56 sm:w-64 sm:h-64 object-cover rounded-3xl shadow-[var(--shadow-elegant)]"
          />
        </div>
        <div className="space-y-5">
          <p className="text-lg leading-relaxed text-foreground/85">
            Hello, I'm <span className="font-semibold text-primary">Mayuri Kohle</span>, an
            engineering student passionate about cloud computing, AI tools, and prompt engineering.
          </p>
          <p className="text-base leading-relaxed text-muted-foreground">
            I'm building my technical skills in cloud platforms, programming, and AI-driven
            technologies. I enjoy learning new concepts and applying them to real-world problems.
          </p>
          <div className="flex flex-wrap gap-2 pt-2">
            {["B.Tech Student", "Cloud Track", "AI Enthusiast", "Lifelong Learner"].map((tag) => (
              <span key={tag} className="px-3 py-1 rounded-full bg-secondary/70 text-xs font-medium text-secondary-foreground border border-border/60">
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const Skills = () => (
  <section id="skills" className="px-5 py-24">
    <div className="max-w-6xl mx-auto">
      <SectionTitle eyebrow="Capabilities" title="My Skills" />
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {skills.map((s, i) => {
          const Icon = s.icon;
          return (
            <div
              key={s.name}
              className="glass-card glass-card-hover reveal p-6 group"
              style={{ transitionDelay: `${i * 60}ms` }}
            >
              <div className="flex items-start gap-4">
                <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-accent to-rose text-primary group-hover:scale-110 transition-transform duration-500">
                  <Icon className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-serif text-lg font-semibold text-primary">{s.name}</h3>
                  <p className="text-sm text-muted-foreground mt-1 leading-relaxed">{s.desc}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  </section>
);

const Achievements = () => (
  <section id="achievements" className="px-5 py-24">
    <div className="max-w-6xl mx-auto">
      <SectionTitle eyebrow="Recognitions" title="My Achievements" />
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {achievements.map((a, i) => (
          <article
            key={a.title}
            className="glass-card glass-card-hover reveal overflow-hidden group"
            style={{ transitionDelay: `${i * 80}ms` }}
          >
            <div className="relative overflow-hidden aspect-[4/3] bg-gradient-to-br from-sand/60 to-accent/30 p-3">
              <img
                src={a.img}
                alt={`${a.title} certificate`}
                loading="lazy"
                width={800}
                height={576}
                className="w-full h-full object-contain rounded-2xl bg-white shadow-sm transition-transform duration-700 group-hover:scale-[1.03]"
              />
              <div className="absolute top-3 right-3 grid h-9 w-9 place-items-center rounded-full bg-white/80 backdrop-blur shadow-md">
                <Award className="h-4 w-4 text-gold" />
              </div>
            </div>
            <div className="p-6">
              <h3 className="font-serif text-lg font-semibold text-primary leading-snug">{a.title}</h3>
              {a.date && <p className="text-xs text-gold font-medium mt-1 tracking-wide">{a.date}</p>}
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{a.desc}</p>
            </div>
          </article>
        ))}
      </div>
    </div>
  </section>
);

const Contact = () => (
  <section id="contact" className="px-5 py-24">
    <div className="max-w-4xl mx-auto">
      <SectionTitle eyebrow="Get in touch" title="Contact Me" />
      <div className="glass-card reveal p-8 sm:p-12 text-center">
        <p className="text-muted-foreground max-w-md mx-auto">
          I'd love to connect — for collaborations, learning together, or simply a conversation.
        </p>
        <div className="mt-8 grid sm:grid-cols-2 gap-4 max-w-xl mx-auto">
          <a
            href="tel:7620388053"
            className="glass-card glass-card-hover p-5 flex items-center gap-4 text-left"
          >
            <div className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-accent to-rose text-primary">
              <Phone className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Phone</p>
              <p className="font-medium text-primary">7620388053</p>
            </div>
          </a>
          <a
            href="mailto:mayurikolhe1110@gmail.com"
            className="glass-card glass-card-hover p-5 flex items-center gap-4 text-left"
          >
            <div className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-accent to-rose text-primary">
              <Mail className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground">Email</p>
              <p className="font-medium text-primary truncate">mayurikolhe1110@gmail.com</p>
            </div>
          </a>
        </div>

        <div className="mt-8 flex justify-center gap-3">
          <Button variant="outline" size="lg" className="rounded-full bg-white/60 backdrop-blur" asChild>
            <a href="#" aria-label="GitHub"><Github className="h-4 w-4 mr-2" /> GitHub</a>
          </Button>
          <Button variant="outline" size="lg" className="rounded-full bg-white/60 backdrop-blur" asChild>
            <a href="#" aria-label="LinkedIn"><Linkedin className="h-4 w-4 mr-2" /> LinkedIn</a>
          </Button>
        </div>
      </div>

      <footer className="mt-16 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Mayuri Kohle · Crafted with care.
      </footer>
    </div>
  </section>
);

const Index = () => {
  useReveal();
  const ref = useRef<HTMLDivElement>(null);
  return (
    <div ref={ref} className="min-h-screen">
      <Nav />
      <main>
        <Hero />
        <Profile />
        <Skills />
        <Achievements />
        <Contact />
      </main>
    </div>
  );
};

export default Index;
